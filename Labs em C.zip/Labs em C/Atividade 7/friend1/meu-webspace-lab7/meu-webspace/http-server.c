#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <sys/socket.h>
#include <netinet/in.h>

#include "parser.tab.h"
#include "parser.yy.h"
#include "http-server.h"

extern CommandNode *commands_list;

int main(int argc, char** argv)
{
    /** variables declaration */
    char *server_root = argv[1];
    char *log_filename = argv[2];
    int _socket, socket_fd, log_fd;
    struct sockaddr_in server, client;
    unsigned int address_size = sizeof(client);
    int port;
    sscanf(argv[3], "%d", &port);

    /** open file of server logs */
    if ((log_fd = open(log_filename, O_CREAT | O_WRONLY | O_APPEND, 0600)) == -1)
    {
        return -1;
    };

    /** creates server */
    _socket = socket(AF_INET, SOCK_STREAM, 0);
    server.sin_family = AF_INET;
    server.sin_port = htons(port);
    server.sin_addr.s_addr = INADDR_ANY;
    bind(_socket, (struct sockaddr*)&server, sizeof(server));
    listen(_socket, 5);

    for(;;) {
        socket_fd = accept(_socket, (struct sockaddr*)&client, &address_size);
        answerAndLogRequest(server_root, socket_fd, log_fd);
        close(socket_fd);
    }

    /** return success */
    return 0;
}

char *statusCode(int status)
{
    static char buffer[100];
    switch (status)
    {
        // Informational 1xx
        STATUS_CODE_CASE(100, "Continue", buffer)
        STATUS_CODE_CASE(101, "Switching Protocols", buffer)
        // Successful 2xx
        STATUS_CODE_CASE(200, "OK", buffer)
        STATUS_CODE_CASE(201, "Created", buffer)
        STATUS_CODE_CASE(202, "Accepted", buffer)
        STATUS_CODE_CASE(203, "Non-Authoritative Information", buffer)
        STATUS_CODE_CASE(204, "No Content", buffer)
        STATUS_CODE_CASE(205, "Reset Content", buffer)
        STATUS_CODE_CASE(206, "Partial Content", buffer)
        // Redirection 3xx
        STATUS_CODE_CASE(300, "Multiple Choices", buffer)
        STATUS_CODE_CASE(301, "Moved Permanently", buffer)
        STATUS_CODE_CASE(302, "Found", buffer)
        STATUS_CODE_CASE(303, "See Other", buffer)
        STATUS_CODE_CASE(304, "Not Modified", buffer)
        STATUS_CODE_CASE(305, "Use Proxy", buffer)
        STATUS_CODE_CASE(307, "Temporary Redirect", buffer)
        // Client Error 4xx
        STATUS_CODE_CASE(400, "Bad Request", buffer)
        STATUS_CODE_CASE(401, "Unauthorized", buffer)
        STATUS_CODE_CASE(402, "Payment Required", buffer)
        STATUS_CODE_CASE(403, "Forbidden", buffer)
        STATUS_CODE_CASE(404, "Not Found", buffer)
        STATUS_CODE_CASE(405, "Method Not Allowed", buffer)
        STATUS_CODE_CASE(406, "Not Acceptable", buffer)
        STATUS_CODE_CASE(407, "Proxy Authentication Required", buffer)
        STATUS_CODE_CASE(408, "Request Timeout", buffer)
        STATUS_CODE_CASE(409, "Conflict", buffer)
        STATUS_CODE_CASE(410, "Gone", buffer)
        STATUS_CODE_CASE(411, "Length Required", buffer)
        STATUS_CODE_CASE(412, "Precondition Failed", buffer)
        STATUS_CODE_CASE(413, "Request Entity Too Large", buffer)
        STATUS_CODE_CASE(414, "Request-URI Too Long", buffer)
        STATUS_CODE_CASE(415, "Unsupported Media Type", buffer)
        STATUS_CODE_CASE(416, "Requested Range Not Satisfiable", buffer)
        STATUS_CODE_CASE(417, "Expectation Failed", buffer)
        // Server Error 5xx
        STATUS_CODE_CASE(500, "Internal Server Error", buffer)
        STATUS_CODE_CASE(501, "Not Implemented", buffer)
        STATUS_CODE_CASE(502, "Bad Gateway", buffer)
        STATUS_CODE_CASE(503, "Service Unavailable", buffer)
        STATUS_CODE_CASE(504, "Gateway Timeout", buffer)
        STATUS_CODE_CASE(505, "HTTP Version Not Supported", buffer)
    }
    return buffer;
}

int getRegFileResource(char *resource_absolute_path, struct stat resource_info, Resource *resource)
{
    int fdr;
    resource->info = resource_info;
    resource->contents = (char *)malloc(resource_info.st_size);

    /** open requested file */
    if ((fdr = open(resource_absolute_path, O_RDONLY, 0600)) == -1)
    {
        return SERVER_ERROR;
    };

    /** reads file and write its contents on buffer */
    if (read(fdr, resource->contents, resource_info.st_size) == -1)
    {
        return SERVER_ERROR;
    }

    /** end with success */
    return SUCCESS;
}

int getResource(char *root_dir_path, char *resource_relative_path, Resource *resource)
{
    int resource_descriptor, i, r = -1;
    char *resource_absolute_path;
    char *default_files[] = {
        "index.html", "/index.html", "welcome.html", "/welcome.html"};
    struct stat resource_info;

    /** concat root dir and resource paths */
    resource_absolute_path = (char *)malloc(
        strlen(root_dir_path) +
        strlen(resource_relative_path) + 1);
    strcpy(resource_absolute_path, root_dir_path);
    strcat(resource_absolute_path, resource_relative_path);

    /** check webspace above access attempt using "../" */
    if(strstr(resource_relative_path, "..") != NULL) {
        r = NOT_ALLOWED;
    }
    /** get resource infos */
    else if (stat(resource_absolute_path, &resource_info) == -1)
    {
        r = NOT_FOUND;
    }

    /** check for read permissions */
    else if (!(resource_info.st_mode & S_IROTH))
    {
        r = FORBIDDEN;
    }

    /** check for file type */
    else if (S_ISREG(resource_info.st_mode))
    {
        /** prints regular file and return 0 if no errors */
        r = getRegFileResource(
            resource_absolute_path,
            resource_info,
            resource);
    }
    else if (S_ISDIR(resource_info.st_mode))
    {
        /** check for directory execute permission */
        if (!(resource_info.st_mode & S_IXOTH))
        {
            r = FORBIDDEN;
        }
        else
        {
            /** recursively check default files at directory */
            for (i = 0; i < 4 && r != SUCCESS; i++)
            {
                r = getResource(resource_absolute_path, default_files[i], resource);
            }
        }
    }
    free(resource_absolute_path);
    return r;
}

char *dateFormat(time_t time)
{
    struct tm *local_time;
    static char buffer[200];

    local_time = gmtime(&time);

    strcpy(buffer, asctime(local_time));
    buffer[strlen(buffer) - 1] = 0;

    return buffer;
}

char *getResponseHeader(Resource *resource, char *connection_header)
{
    static char buffer[MAX_BUFFER_SIZE];
    int offset = 0;

    offset += sprintf(buffer, HTTP_PROTOCOL " %s\r\n", statusCode(SUCCESS));
    offset += sprintf(buffer + offset, "Date: %s GMT\r\n", dateFormat(time(NULL)));
    offset += sprintf(buffer + offset, "Server: Servidor HTTP v0.1 de Arthur Cantarela\r\n");
    offset += sprintf(buffer + offset, "Connection: %s\r\n", connection_header);
    offset += sprintf(buffer + offset, "Last-Modified: %s GMT\r\n", dateFormat(resource->info.st_mtim.tv_sec));
    offset += sprintf(buffer + offset, "Content-Length: %ld\r\n", resource->info.st_size);
    offset += sprintf(buffer + offset, "Content-Type: text/html\r\n");
    sprintf(buffer + offset, "\r\n");

    return buffer;
}

char *traceResponseHeader(char *request_buffer, char *connection_header)
{
    static char buffer[MAX_BUFFER_SIZE];
    int offset = 0;

    offset += sprintf(buffer, HTTP_PROTOCOL " %s\r\n", statusCode(SUCCESS));
    offset += sprintf(buffer + offset, "Date: %s GMT\r\n", dateFormat(time(NULL)));
    offset += sprintf(buffer + offset, "Server: Servidor HTTP v0.1 de Arthur Cantarela\r\n");
    offset += sprintf(buffer + offset, "Connection: %s\r\n", connection_header);
    offset += sprintf(buffer + offset, "Content-Length: %ld\r\n", strlen(request_buffer));
    offset += sprintf(buffer + offset, "Content-Type: message/http\r\n");
    sprintf(buffer + offset, "\r\n");

    return buffer;
}

char *optionsResponseHeader(char *connection_header)
{
    static char buffer[MAX_BUFFER_SIZE];
    int offset = 0;

    offset += sprintf(buffer, HTTP_PROTOCOL " %s\r\n", statusCode(SUCCESS));
    offset += sprintf(buffer + offset, "Allow: OPTIONS, GET, HEAD, TRACE\r\n");
    offset += sprintf(buffer + offset, "Date: %s GMT\r\n", dateFormat(time(NULL)));
    offset += sprintf(buffer + offset, "Server: Servidor HTTP v0.1 de Arthur Cantarela\r\n");
    offset += sprintf(buffer + offset, "Connection: %s\r\n", connection_header);
    offset += sprintf(buffer + offset, "Content-Length: 0");
    sprintf(buffer + offset, "\r\n");

    return buffer;
}

char *errorResponseHeader(int status, char *connection_header)
{
    static char buffer[MAX_BUFFER_SIZE];
    int offset = 0;

    offset += sprintf(buffer, HTTP_PROTOCOL " %s\r\n", statusCode(status));
    offset += sprintf(buffer + offset, "Date: %s GMT\r\n", dateFormat(time(NULL)));
    offset += sprintf(buffer + offset, "Server: Servidor HTTP v0.1 de Arthur Cantarela\r\n");
    offset += sprintf(buffer + offset, "Connection: %s\r\n", connection_header);
    offset += sprintf(buffer + offset, "Content-Length: 0\r\n");
    sprintf(buffer + offset, "\r\n");

    return buffer;
}

int answerAndLogRequest(char *server_root, int socket_fd, int log_fd)
{
    char request_buffer[MAX_BUFFER_SIZE];
    char log_header[] = "##################\r\n# new log entry\r\n##################\r\n";
    char log_footer[] = "##################\r\n# end of log entry\r\n##################\r\n\r\n\r\n";
    char log_request_header[] = "# REQUEST:\r\n";
    char log_response_header[] = "# RESPONSE:\r\n";
    char *response_buffer;
    char request_method[10];
    char request_uri[1024];
    char request_protocol[10];
    char connection_header[20];
    int parse_error;

    int response_status;
    CommandNode *current_command;
    Resource resource;
    resource.contents = NULL;

    YY_BUFFER_STATE buffer_state;

    /** read HTTP request on socket */
    if (read(socket_fd, request_buffer, sizeof(request_buffer)) == -1)
    {
        return -1;
    };
    /** truncate end of request */
    if(strstr(request_buffer, "\r\n\r\n") != NULL) {
        *(strstr(request_buffer, "\r\n\r\n")+4) = '\0';
    }

    /** parse http request */
    buffer_state = yy_scan_string(request_buffer);
    parse_error = yyparse();
    yy_delete_buffer(buffer_state);

    /** start logging */
    if (write(log_fd, log_header, strlen(log_header)) == -1)
    {
        return -1;
    }
    if (write(log_fd, log_request_header, strlen(log_request_header)) == -1)
    {
        return -1;
    }
    if (write(log_fd, request_buffer, strlen(request_buffer)) == -1)
    {
        return -1;
    }
    if (write(log_fd, log_response_header, strlen(log_response_header)) == -1)
    {
        return -1;
    }

    /** 400 response in case of parser error */
    strcpy(connection_header, DEFAULT_CONNECTION);
    if (parse_error || commands_list == NULL)
    {
        response_buffer = errorResponseHeader(BAD_REQUEST, connection_header);
        fflush(stdout);
        write(STDOUT_FILENO, response_buffer, strlen(response_buffer));
        if (write(socket_fd, response_buffer, strlen(response_buffer)) == -1)
        {
            return -1;
        }
        if (write(log_fd, response_buffer, strlen(response_buffer)) == -1)
        {
            return -1;
        }
        if (write(log_fd, log_footer, strlen(log_footer)) == -1)
        {
            return -1;
        }
        return 0;
    }

    /** retrieve request connection field */
    current_command = commands_list;
    while (current_command != NULL)
    {
        if (strcmp(current_command->text, "Connection") == 0)
        {
            strcpy(connection_header, current_command->params->text);
        }
        current_command = current_command->next;
    }

    /** retrieve info from first line of http request */
    strcpy(request_method, commands_list->text);
    strcpy(request_uri, commands_list->params->text);
    strcpy(request_protocol, commands_list->params->next->text);
    freeCommandList(commands_list);
    commands_list = NULL;
    current_command = NULL;

    /** 505 response in case of wrong http protocol */
    if (strcmp(HTTP_PROTOCOL, request_protocol) != 0)
    {
        printf("%s", errorResponseHeader(NOT_SUPPORTED, connection_header));
        return 0;
    }

    if (strcmp(request_method, "GET") == 0 || strcmp(request_method, "HEAD") == 0)
    {
        /** handle GET/HEAD requests */
        response_status = getResource(server_root, request_uri, &resource);
        if (response_status == SUCCESS)
        {
            /** handle GET/HEAD sucessful request */
            response_buffer = getResponseHeader(&resource, connection_header);
            /** write successful response header */
            fflush(stdout);
            write(STDOUT_FILENO, response_buffer, strlen(response_buffer));
            if (write(socket_fd, response_buffer, strlen(response_buffer)) == -1)
            {
                return -1;
            }
            /** log successful response header */
            if (write(log_fd, response_buffer, strlen(response_buffer)) == -1)
            {
                return -1;
            }
            if (strcmp(request_method, "HEAD") != 0)
            {
                /** write successful response body */
                fflush(stdout);
                write(STDOUT_FILENO, resource.contents, strlen(resource.contents));
                if (write(socket_fd, resource.contents, strlen(resource.contents)) == -1)
                {
                    return -1;
                }
                fflush(stdout);
                write(STDOUT_FILENO, "\r\n", strlen("\r\n"));
                if (write(socket_fd, "\r\n", strlen("\r\n")) == -1)
                {
                    return -1;
                }
            }
        }
        else
        {
            /** handle GET/HEAD failed request */
            response_buffer = errorResponseHeader(response_status, connection_header);
            /** write failed response body */
            fflush(stdout);
            write(STDOUT_FILENO, response_buffer, strlen(response_buffer));
            if (write(socket_fd, response_buffer, strlen(response_buffer)) == -1)
            {
                return -1;
            }
            /** log failed response */
            if (write(log_fd, response_buffer, strlen(response_buffer)) == -1)
            {
                return -1;
            }
        };
    }
    else if (strcmp(request_method, "TRACE") == 0)
    {
        /** handle TRACE requests, always successful */
        response_buffer = traceResponseHeader(request_buffer, connection_header);
        /** write response header */
        fflush(stdout);
        write(STDOUT_FILENO, response_buffer, strlen(response_buffer));
        if (write(socket_fd, response_buffer, strlen(response_buffer)) == -1)
        {
            return -1;
        }
        fflush(stdout);
        write(STDOUT_FILENO, request_buffer, strlen(request_buffer));
        if (write(socket_fd, request_buffer, strlen(request_buffer)) == -1)
        {
            return -1;
        }
        /** write response body */
        fflush(stdout);
        write(STDOUT_FILENO, "\r\n", strlen("\r\n"));
        if (write(socket_fd, "\r\n", strlen("\r\n")) == -1)
        {
            return -1;
        }
        /** log response header */
        if (write(log_fd, response_buffer, strlen(response_buffer)) == -1)
        {
            return -1;
        }
    }
    else if (strcmp(request_method, "OPTIONS") == 0)
    {
        /** handle OPTIONS requests, always successful */
        response_buffer = optionsResponseHeader(connection_header);
        /** write response */
        fflush(stdout);
        write(STDOUT_FILENO, response_buffer, strlen(response_buffer));
        if (write(socket_fd, response_buffer, strlen(response_buffer)) == -1)
        {
            return -1;
        }
        /** log response */
        if (write(log_fd, response_buffer, strlen(response_buffer)) == -1)
        {
            return -1;
        }
    }
    else
    {
        /** handle not allowed methods */
        response_buffer = errorResponseHeader(NOT_IMPLEMENTED, connection_header);
        /** write response */
        fflush(stdout);
        write(STDOUT_FILENO, response_buffer, strlen(response_buffer));
        if (write(socket_fd, response_buffer, strlen(response_buffer)) == -1)
        {
            return -1;
        }
        /** log response */
        if (write(log_fd, response_buffer, strlen(response_buffer)) == -1)
        {
            return -1;
        }
    }
    /** finish logging */
    if (write(log_fd, log_footer, strlen(log_footer)) == -1)
    {
        return -1;
    }
    /** free some memory */
    if (resource.contents != NULL)
    {
        free(resource.contents);
    }
    return 0;
}

void freeCommandList(CommandNode* commands)
{
    if(commands == NULL) return;
    freeCommandList(commands->next);
    commands->next = NULL;
    freeParamList(commands->params);
    free(commands);
}

void freeParamList(ParamNode* params)
{
    if(params == NULL) return;
    freeParamList(params->next);
    params->next = NULL;
    free(params);
}