#!/bin/bash
yacc -d -o parser.tab.c parser.y
flex --header-file=parser.yy.h -o parser.yy.c parser.l
gcc -o http-server parser.tab.c parser.yy.c http-server.c -ly -ll