#include <time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/stat.h>
#include "commands.h"

#define MAX_BUFFER_SIZE 32768
#define STATUS_CODE_CASE(code, status, buffer) \
    case code:                                 \
        strcpy(buffer, #code " " status);      \
        break;

#define HTTP_PROTOCOL "HTTP/1.1"
#define DEFAULT_CONNECTION "close"

#define SUCCESS 200

#define BAD_REQUEST 400
#define NOT_FOUND 404
#define FORBIDDEN 403
#define NOT_ALLOWED 405

#define SERVER_ERROR 500
#define NOT_IMPLEMENTED 501
#define NOT_SUPPORTED 505

typedef struct Resource
{
    char *contents;
    struct stat info;
} Resource;

/**
 * @brief gets http status-code complete string e.g.: "200 OK"
 * @param[in] status http status integer
 * @return status-code complete string
*/
char *statusCode(int status);

/**
 * @brief   open and read a known regular file and
 *          saves its contents and metadata
 * @param[in] resource_absolute_path    absolute path of regular file
 * @param[in] resource_info             struct with file stat (metadata)
 * @param[out] resource                 pointer to struct where content and metadata
 *                                      will be kept
 *
 * @retval SUCCESS      on success
 * @retval SERVER_ERROR if file couldn't be opened or read
 */
int getRegFileResource(char *resource_absolute_path, struct stat resource_info, Resource *resource);

/**
 * @brief   attempt to open and read a resource from its workspace
 *          and relative path, either directly or looking for default
 *          files in directory, and handle permission errors
 * @param[in] root_dir_path             workspace absolute path
 * @param[in] resource_relative_path    relative path of resource
 * @param[out] resource                 pointer to struct where content and metadata
 *                                      will be kept
 *
 * @retval SUCCESS      on success
 * @retval NOT_FOUND    resource was not found
 * @retval FORBIDDEN    resource with no read/execute permission
 * @retval SERVER_ERROR file couldn't be opend or read for some other reason
 */
int getResource(char *root_dir_path, char *resource_relative_path, Resource *resource);

/**
 * @brief   generate human readable string from timestamp
 * @param[in] time  timestamp
 * @return human readable time string, in GMT
 */
char *dateFormat(time_t time);

/**
 * @brief   generate response header for successful GET or HEAD requests
 * @param[in] resource          resource content and metadata
 * @param[in] connection_header Connection value of request
 * @return GET/HEAD response complete header string
 */
char *getResponseHeader(Resource *resource, char *connection_header);

/**
 * @brief   generate response header for successful TRACE requests
 * @param[in] request_buffer    both header and body of request
 * @param[in] connection_header Connection value of request
 * @return TRACE response complete header string
 */
char *traceResponseHeader(char *request_buffer, char *connection_header);

/**
 * @brief   generate response header for successful OPTIONS requests
 * @param[in] connection_header Connection value of request
 * @return OPTIONS response complete header string
 */
char *optionsResponseHeader(char *connection_header);

/**
 * @brief   generate generic response header for failed requests
 * @param[in] status            HTTP status of error e.g.: 4XX or 5XX
 * @param[in] connection_header Connection value of request
 * @return error response complete header string
 */
char *errorResponseHeader(int status, char *connection_header);

/**
 * @brief handle incoming request in socket, send response and log
 * @param[in] server_root   webspace path
 * @param[in] socket_fd     socket file descriptor
 * @param[in] log_fd        log file descriptor
 * @retval 0    handle success
 * @retval -1   handle error
*/
int answerAndLogRequest(char *server_root, int socket_fd, int log_fd);

/**
 * @brief recursively frees memory of commands and params lists
 * @param[in] commands command list
*/
void freeCommandList(CommandNode* commands);

/**
 * @brief recursively frees memory of params list
 * @param[in] params param list
*/
void freeParamList(ParamNode* params);
