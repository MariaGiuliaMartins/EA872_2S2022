# Lab 06

Maria Giulia Martins <br>
202819 <br>

## Criação de Estrutura de Diretórios do Web Space e da Atividade no Geral

```
.
├── meu-webspace
│   ├── dir1
│   │   ├── dir11
│   │   ├── texto1.html
│   │   └── texto2.html
│   ├── dir2
│   ├── index.html
│   └── welcome.html
├── parser.l
├── parser.tab.c
├── parser.tab.h
├── parser.y
├── parser.yy.c
├── readme.md
└── servidor.c
```

## Configuração das Permissões

No início do Roteiro da Atividade 6, foi solicitado a criação de arquivos e pastas do `meu-webspace` com permissões específicas. Para garantir tais permissões, execute os seguintes comandos:

```
chmod +rwx meu-webspace
chmod +r index.html
chmod +rwx dir1
chmod +rwx dir1/dir11
chmod +r dir1/texto1.html
chmod -r dir1/texto2.html
chmod +rw dir2
chmod -x dir2
```

## Compilação do Código

Para a execução do código implementado em `servidor.c` execute os seguintes comandos:

```
yacc -d -o parser.tab.c parser.y
flex -o parser.yy.c parser.l
gcc -o servidor.c parser.tab.c parser.yy.c servidor.c -ly -ll
```

Observação: para a execução do último comando o erro 
```/usr/bin/ld: cannot find -ly
collect2: error: ld returned 1 exit status``` 
ocorria. Assim, a partir de sugestões dos colegas, instalou-se o libbison-dev (`apt install libbison-dev`) e a execução correta foi possível.
