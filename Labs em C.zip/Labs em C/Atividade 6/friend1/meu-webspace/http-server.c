#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>

#include "parser.tab.h"
#include "commands.h"

extern CommandNode *commands_list;
void yyerror() {}
int yy_scan_string(char *str);

#define MAX_BUFFER_SIZE 32768
#define STATUS_CODE_CASE(code, status, buffer) \
    case code:                                 \
        strcpy(buffer, #code " " status);      \
        break;

#define HTTP_PROTOCOL "HTTP/1.1"
#define DEFAULT_CONNECTION "close"

#define SUCCESS 200

#define BAD_REQUEST 400
#define NOT_FOUND 404
#define FORBIDDEN 403
#define NOT_ALLOWED 405

#define SERVER_ERROR 500
#define NOT_IMPLEMENTED 501
#define NOT_SUPPORTED 505

typedef struct Resource
{
    char *contents;
    struct stat info;
} Resource;

/**
 * @brief gets http status-code complete string e.g.: "200 OK"
 * @param[in] status http status integer
 * @return status-code complete string
*/
char *statusCode(int status);

/**
 * @brief   open and read a known regular file and
 *          saves its contents and metadata
 * @param[in] resource_absolute_path    absolute path of regular file
 * @param[in] resource_info             struct with file stat (metadata)
 * @param[out] resource                 pointer to struct where content and metadata
 *                                      will be kept
 *
 * @retval SUCCESS      on success
 * @retval SERVER_ERROR if file couldn't be opened or read
 */
int getRegFileResource(char *resource_absolute_path, struct stat resource_info, Resource *resource);

/**
 * @brief   attempt to open and read a resource from its workspace
 *          and relative path, either directly or looking for default
 *          files in directory, and handle permission errors
 * @param[in] root_dir_path             workspace absolute path
 * @param[in] resource_relative_path    relative path of resource
 * @param[out] resource                 pointer to struct where content and metadata
 *                                      will be kept
 *
 * @retval SUCCESS      on success
 * @retval NOT_FOUND    resource was not found
 * @retval FORBIDDEN    resource with no read/execute permission
 * @retval SERVER_ERROR file couldn't be opend or read for some other reason
 */
int getResource(char *root_dir_path, char *resource_relative_path, Resource *resource);

/**
 * @brief   generate human readable string from timestamp
 * @param[in] time  timestamp
 * @return human readable time string, in GMT
 */
char *dateFormat(time_t time);

/**
 * @brief   generate response header for successful GET or HEAD requests
 * @param[in] resource          resource content and metadata
 * @param[in] connection_header Connection value of request
 * @return GET/HEAD response complete header string
 */
char *getResponseHeader(Resource *resource, char *connection_header);

/**
 * @brief   generate response header for successful TRACE requests
 * @param[in] request_buffer    both header and body of request
 * @param[in] connection_header Connection value of request
 * @return TRACE response complete header string
 */
char *traceResponseHeader(char *request_buffer, char *connection_header);

/**
 * @brief   generate response header for successful OPTIONS requests
 * @param[in] connection_header Connection value of request
 * @return OPTIONS response complete header string
 */
char *optionsResponseHeader(char *connection_header);

/**
 * @brief   generate generic response header for failed requests
 * @param[in] status            HTTP status of error e.g.: 4XX or 5XX
 * @param[in] connection_header Connection value of request
 * @return error response complete header string
 */
char *errorResponseHeader(int status, char *connection_header);

int main(int argc, char *argv[])
{
    /** variables declaration */
    char request_buffer[MAX_BUFFER_SIZE];
    char log_header[] = "##################\r\n# new log entry\r\n##################\r\n";
    char log_footer[] = "##################\r\n# end of log entry\r\n##################\r\n\r\n\r\n";
    char log_request_header[] = "# REQUEST:\r\n";
    char log_response_header[] = "# RESPONSE:\r\n";
    char *response_buffer;
    char request_method[10];
    char request_uri[1024];
    char request_protocol[10];
    char connection_header[20];
    int parse_error;
    char *server_root = argv[1];
    char *request_filename = argv[2];
    char *response_filename = argv[3];
    char *log_filename = argv[4];
    int request_fd, response_fd, log_fd;
    int response_status;
    CommandNode *current_command;
    Resource resource;
    resource.contents = NULL;

    /** open and read file of HTTP request */
    if ((request_fd = open(request_filename, O_RDONLY, 0600)) == -1)
    {
        return -1;
    };
    if (read(request_fd, request_buffer, sizeof(request_buffer)) == -1)
    {
        return -1;
    };

    /** create file to store HTTP response */
    if ((response_fd = creat(response_filename, 0600)) == -1)
    {
        return -1;
    };

    /** open file of server logs */
    if ((log_fd = open(log_filename, O_CREAT | O_WRONLY | O_APPEND, 0600)) == -1)
    {
        return -1;
    };

    /** parse http request */
    yy_scan_string(request_buffer);
    parse_error = yyparse();

    /** start logging */
    if (write(log_fd, log_header, strlen(log_header)) == -1)
    {
        return -1;
    }
    if (write(log_fd, log_request_header, strlen(log_request_header)) == -1)
    {
        return -1;
    }
    if (write(log_fd, request_buffer, strlen(request_buffer)) == -1)
    {
        return -1;
    }
    if (write(log_fd, log_response_header, strlen(log_response_header)) == -1)
    {
        return -1;
    }

    /** 400 response in case of parser error */
    strcpy(connection_header, DEFAULT_CONNECTION);
    if (parse_error || commands_list == NULL)
    {
        response_buffer = errorResponseHeader(BAD_REQUEST, connection_header);
        if (write(response_fd, response_buffer, strlen(response_buffer)) == -1)
        {
            return -1;
        }
        if (write(log_fd, response_buffer, strlen(response_buffer)) == -1)
        {
            return -1;
        }
        if (write(log_fd, log_footer, strlen(log_footer)) == -1)
        {
            return -1;
        }
        return 0;
    }

    /** retrieve request connection field */
    current_command = commands_list;
    while (current_command != NULL)
    {
        if (strcmp(current_command->text, "Connection") == 0)
        {
            strcpy(connection_header, current_command->params->text);
        }
        current_command = current_command->next;
    }

    /** retrieve info from first line of http request */
    strcpy(request_method, commands_list->text);
    strcpy(request_uri, commands_list->params->text);
    strcpy(request_protocol, commands_list->params->next->text);

    /** 505 response in case of wrong http protocol */
    if (strcmp(HTTP_PROTOCOL, request_protocol) != 0)
    {
        printf("%s", errorResponseHeader(NOT_SUPPORTED, connection_header));
        return 0;
    }

    if (strcmp(request_method, "GET") == 0 || strcmp(request_method, "HEAD") == 0)
    {
        /** handle GET/HEAD requests */
        response_status = getResource(server_root, request_uri, &resource);
        if (response_status == SUCCESS)
        {
            /** handle GET/HEAD sucessful request */
            response_buffer = getResponseHeader(&resource, connection_header);
            /** write successful response header */
            if (write(response_fd, response_buffer, strlen(response_buffer)) == -1)
            {
                return -1;
            }
            /** log successful response header */
            if (write(log_fd, response_buffer, strlen(response_buffer)) == -1)
            {
                return -1;
            }
            if (strcmp(request_method, "HEAD") != 0)
            {
                /** write successful response body */
                if (write(response_fd, resource.contents, strlen(resource.contents)) == -1)
                {
                    return -1;
                }
                if (write(response_fd, "\r\n", strlen("\r\n")) == -1)
                {
                    return -1;
                }
            }
        }
        else
        {
            /** handle GET/HEAD failed request */
            response_buffer = errorResponseHeader(response_status, connection_header);
            /** write failed response body */
            if (write(response_fd, response_buffer, strlen(response_buffer)) == -1)
            {
                return -1;
            }
            /** log failed response */
            if (write(log_fd, response_buffer, strlen(response_buffer)) == -1)
            {
                return -1;
            }
        };
    }
    else if (strcmp(request_method, "TRACE") == 0)
    {
        /** handle TRACE requests, always successful */
        response_buffer = traceResponseHeader(request_buffer, connection_header);
        /** write response */
        if (write(response_fd, response_buffer, strlen(response_buffer)) == -1)
        {
            return -1;
        }
        if (write(response_fd, request_buffer, strlen(request_buffer)) == -1)
        {
            return -1;
        }
        if (write(response_fd, "\r\n", strlen("\r\n")) == -1)
        {
            return -1;
        }
        /** log response header */
        if (write(log_fd, response_buffer, strlen(response_buffer)) == -1)
        {
            return -1;
        }
    }
    else if (strcmp(request_method, "OPTIONS") == 0)
    {
        /** handle OPTIONS requests, always successful */
        response_buffer = optionsResponseHeader(connection_header);
        /** write response */
        if (write(response_fd, response_buffer, strlen(response_buffer)) == -1)
        {
            return -1;
        }
        /** log response */
        if (write(log_fd, response_buffer, strlen(response_buffer)) == -1)
        {
            return -1;
        }
    }
    else
    {
        /** handle not allowed methods */
        response_buffer = errorResponseHeader(NOT_ALLOWED, connection_header);
        /** write response */
        if (write(response_fd, response_buffer, strlen(response_buffer)) == -1)
        {
            return -1;
        }
        /** log response */
        if (write(log_fd, response_buffer, strlen(response_buffer)) == -1)
        {
            return -1;
        }
    }
    /** finish logging */
    if (write(log_fd, log_footer, strlen(log_footer)) == -1)
    {
        return -1;
    }
    /** free some memory */
    if (resource.contents != NULL)
    {
        free(resource.contents);
    }
    /** return success */
    return 0;
}

char *statusCode(int status)
{
    static char buffer[100];
    switch (status)
    {
        // Informational 1xx
        STATUS_CODE_CASE(100, "Continue", buffer)
        STATUS_CODE_CASE(101, "Switching Protocols", buffer)
        // Successful 2xx
        STATUS_CODE_CASE(200, "OK", buffer)
        STATUS_CODE_CASE(201, "Created", buffer)
        STATUS_CODE_CASE(202, "Accepted", buffer)
        STATUS_CODE_CASE(203, "Non-Authoritative Information", buffer)
        STATUS_CODE_CASE(204, "No Content", buffer)
        STATUS_CODE_CASE(205, "Reset Content", buffer)
        STATUS_CODE_CASE(206, "Partial Content", buffer)
        // Redirection 3xx
        STATUS_CODE_CASE(300, "Multiple Choices", buffer)
        STATUS_CODE_CASE(301, "Moved Permanently", buffer)
        STATUS_CODE_CASE(302, "Found", buffer)
        STATUS_CODE_CASE(303, "See Other", buffer)
        STATUS_CODE_CASE(304, "Not Modified", buffer)
        STATUS_CODE_CASE(305, "Use Proxy", buffer)
        STATUS_CODE_CASE(307, "Temporary Redirect", buffer)
        // Client Error 4xx
        STATUS_CODE_CASE(400, "Bad Request", buffer)
        STATUS_CODE_CASE(401, "Unauthorized", buffer)
        STATUS_CODE_CASE(402, "Payment Required", buffer)
        STATUS_CODE_CASE(403, "Forbidden", buffer)
        STATUS_CODE_CASE(404, "Not Found", buffer)
        STATUS_CODE_CASE(405, "Method Not Allowed", buffer)
        STATUS_CODE_CASE(406, "Not Acceptable", buffer)
        STATUS_CODE_CASE(407, "Proxy Authentication Required", buffer)
        STATUS_CODE_CASE(408, "Request Timeout", buffer)
        STATUS_CODE_CASE(409, "Conflict", buffer)
        STATUS_CODE_CASE(410, "Gone", buffer)
        STATUS_CODE_CASE(411, "Length Required", buffer)
        STATUS_CODE_CASE(412, "Precondition Failed", buffer)
        STATUS_CODE_CASE(413, "Request Entity Too Large", buffer)
        STATUS_CODE_CASE(414, "Request-URI Too Long", buffer)
        STATUS_CODE_CASE(415, "Unsupported Media Type", buffer)
        STATUS_CODE_CASE(416, "Requested Range Not Satisfiable", buffer)
        STATUS_CODE_CASE(417, "Expectation Failed", buffer)
        // Server Error 5xx
        STATUS_CODE_CASE(500, "Internal Server Error", buffer)
        STATUS_CODE_CASE(501, "Not Implemented", buffer)
        STATUS_CODE_CASE(502, "Bad Gateway", buffer)
        STATUS_CODE_CASE(503, "Service Unavailable", buffer)
        STATUS_CODE_CASE(504, "Gateway Timeout", buffer)
        STATUS_CODE_CASE(505, "HTTP Version Not Supported", buffer)
    }
    return buffer;
}

int getRegFileResource(char *resource_absolute_path, struct stat resource_info, Resource *resource)
{
    int fdr;
    resource->info = resource_info;
    resource->contents = (char *)malloc(resource_info.st_size);

    /** open requested file */
    if ((fdr = open(resource_absolute_path, O_RDONLY, 0600)) == -1)
    {
        return SERVER_ERROR;
    };

    /** reads file and write its contents on buffer */
    if (read(fdr, resource->contents, resource_info.st_size) == -1)
    {
        return SERVER_ERROR;
    }

    /** end with success */
    return SUCCESS;
}

int getResource(char *root_dir_path, char *resource_relative_path, Resource *resource)
{
    int resource_descriptor, i, r = -1;
    char *resource_absolute_path;
    char *default_files[] = {
        "index.html", "/index.html", "welcome.html", "/welcome.html"};
    struct stat resource_info;

    /** concat root dir and resource paths */
    resource_absolute_path = (char *)malloc(
        strlen(root_dir_path) +
        strlen(resource_relative_path) + 1);
    strcpy(resource_absolute_path, root_dir_path);
    strcat(resource_absolute_path, resource_relative_path);

    /** get resource infos */
    if (stat(resource_absolute_path, &resource_info) == -1)
    {
        r = NOT_FOUND;
    }

    /** check for read permissions */
    else if (!(resource_info.st_mode & S_IROTH))
    {
        r = FORBIDDEN;
    }

    /** check for file type */
    else if (S_ISREG(resource_info.st_mode))
    {
        /** prints regular file and return 0 if no errors */
        r = getRegFileResource(
            resource_absolute_path,
            resource_info,
            resource);
    }
    else if (S_ISDIR(resource_info.st_mode))
    {
        /** check for directory execute permission */
        if (!(resource_info.st_mode & S_IXOTH))
        {
            r = FORBIDDEN;
        }
        else
        {
            /** recursively check default files at directory */
            for (i = 0; i < 4 && r != SUCCESS; i++)
            {
                r = getResource(resource_absolute_path, default_files[i], resource);
            }
        }
    }
    free(resource_absolute_path);
    return r;
}

char *dateFormat(time_t time)
{
    struct tm *local_time;
    static char buffer[200];

    local_time = gmtime(&time);

    strcpy(buffer, asctime(local_time));
    buffer[strlen(buffer) - 1] = 0;

    return buffer;
}

char *getResponseHeader(Resource *resource, char *connection_header)
{
    static char buffer[MAX_BUFFER_SIZE];
    int offset = 0;

    offset += sprintf(buffer, HTTP_PROTOCOL " %s\r\n", statusCode(SUCCESS));
    offset += sprintf(buffer + offset, "Date: %s GMT\r\n", dateFormat(time(NULL)));
    offset += sprintf(buffer + offset, "Server: Servidor HTTP v0.1 de Arthur Cantarela\r\n");
    offset += sprintf(buffer + offset, "Connection: %s\r\n", connection_header);
    offset += sprintf(buffer + offset, "Last-Modified: %s GMT\r\n", dateFormat(resource->info.st_mtim.tv_sec));
    offset += sprintf(buffer + offset, "Content-Length: %ld\r\n", resource->info.st_size);
    offset += sprintf(buffer + offset, "Content-Type: text/html\r\n");
    sprintf(buffer + offset, "\r\n");

    return buffer;
}

char *traceResponseHeader(char *request_buffer, char *connection_header)
{
    static char buffer[MAX_BUFFER_SIZE];
    int offset = 0;

    offset += sprintf(buffer, HTTP_PROTOCOL " %s\r\n", statusCode(SUCCESS));
    offset += sprintf(buffer + offset, "Date: %s GMT\r\n", dateFormat(time(NULL)));
    offset += sprintf(buffer + offset, "Server: Servidor HTTP v0.1 de Arthur Cantarela\r\n");
    offset += sprintf(buffer + offset, "Connection: %s\r\n", connection_header);
    offset += sprintf(buffer + offset, "Content-Length: %ld\r\n", strlen(request_buffer));
    offset += sprintf(buffer + offset, "Content-Type: message/http\r\n");
    sprintf(buffer + offset, "\r\n");

    return buffer;
}

char *optionsResponseHeader(char *connection_header)
{
    static char buffer[MAX_BUFFER_SIZE];
    int offset = 0;

    offset += sprintf(buffer, HTTP_PROTOCOL " %s\r\n", statusCode(SUCCESS));
    offset += sprintf(buffer + offset, "Allow: OPTIONS, GET, HEAD, TRACE\r\n");
    offset += sprintf(buffer + offset, "Date: %s GMT\r\n", dateFormat(time(NULL)));
    offset += sprintf(buffer + offset, "Server: Servidor HTTP v0.1 de Arthur Cantarela\r\n");
    offset += sprintf(buffer + offset, "Connection: %s\r\n", connection_header);
    offset += sprintf(buffer + offset, "Content-Length: 0");
    sprintf(buffer + offset, "\r\n");

    return buffer;
}

char *errorResponseHeader(int status, char *connection_header)
{
    static char buffer[MAX_BUFFER_SIZE];
    int offset = 0;

    offset += sprintf(buffer, HTTP_PROTOCOL " %s\r\n", statusCode(status));
    offset += sprintf(buffer + offset, "Date: %s GMT\r\n", dateFormat(time(NULL)));
    offset += sprintf(buffer + offset, "Server: Servidor HTTP v0.1 de Arthur Cantarela\r\n");
    offset += sprintf(buffer + offset, "Connection: %s\r\n", connection_header);
    offset += sprintf(buffer + offset, "Content-Length: 0\r\n");
    sprintf(buffer + offset, "\r\n");

    return buffer;
}