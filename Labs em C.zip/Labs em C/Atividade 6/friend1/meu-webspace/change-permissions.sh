#!/bin/bash
chmod +rwx .
chmod +r index.html
chmod +rwx dir1
chmod +rwx dir1/dir11
chmod +r dir1/texto1.html
chmod -r dir1/texto2.html
chmod +rw dir2
chmod -x dir2