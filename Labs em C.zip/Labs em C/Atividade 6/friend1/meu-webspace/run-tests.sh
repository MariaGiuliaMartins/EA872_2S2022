#!/bin/bash
for file in requests/*;
do
    response_file=$(echo $file | sed "s+requests/+responses/+")
    ./http-server `pwd` $file $response_file log.txt
done;