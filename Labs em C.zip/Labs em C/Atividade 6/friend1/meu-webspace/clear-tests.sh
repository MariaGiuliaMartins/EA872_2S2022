#!/bin/bash
rm -f responses/*
truncate -s 0 log.txt