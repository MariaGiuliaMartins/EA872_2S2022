#!/bin/bash
yacc -d -o parser.tab.c parser.y
flex -o parser.yy.c parser.l
gcc -o http-server parser.tab.c parser.yy.c http-server.c -ly -ll