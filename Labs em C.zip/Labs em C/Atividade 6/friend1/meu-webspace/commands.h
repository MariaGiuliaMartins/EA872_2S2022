typedef struct ParamNode {
        char* text;
        struct ParamNode* next;
    } ParamNode;

typedef struct CommandNode {
    char* text;
    ParamNode* params;
    struct CommandNode* next;
} CommandNode;
