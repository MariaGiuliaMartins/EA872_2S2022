main() {
  float ea800;
  float um, dois, tres, quatro, cinco,seis, sete, oito;
  um=2;
  dois=tres;
  tres=1;
  quatro=0;
  cinco=8;
  seis=1;
  oito=sete+seis;
  ea800=(10.0-(um+dois+tres+quatro+cinco+seis+sete+oito));
  ea800=10.0;
}
