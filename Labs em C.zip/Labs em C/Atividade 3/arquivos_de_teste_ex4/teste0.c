main() {
  int i,j,k;
  float semestre,ea800=10.0;
  i=0;
  j=i+5;
  j=j+1;
  i=k;
  k=0;
  semestre=ea800;
}
