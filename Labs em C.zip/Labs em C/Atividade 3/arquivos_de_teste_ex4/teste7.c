main() {
  float media;
  float um=11,dois=12,tres,quatro=14,cinco=15;
  tres=cinco;
  media=((um+dois+tres+quatro+cinco)/5);
}
