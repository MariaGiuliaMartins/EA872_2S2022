main() {
  int dia=16,mes=08,ano=2045,i;
  float tempo,espaco;
  i=dia;
  dia=i;
  espaco=tempo;
  ano=0;
  dia=0;
  mes=0;
}
