main() {
  float a,b,c;
  float d,e,f;
  e=a+b+12;
  c=34*(d+e);
  f=e+c;
}
