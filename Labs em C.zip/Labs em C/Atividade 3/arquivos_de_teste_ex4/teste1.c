main() {
  int varA=0, varB=0,varC;
  float varD,varE;
  varC=varA * varB;
  varD=varE;
  varA=120;
  varB=145;
  varC=varA+varB+ varC;
}
