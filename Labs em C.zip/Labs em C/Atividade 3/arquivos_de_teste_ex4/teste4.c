main() {
  float aaaaa;
  float bbbbb;
  float ccccc;
  float ddddd;
  bbbbb=9;
  aaaaa=bbbbb+ccccc;
  ddddd=aaaaa;
}
