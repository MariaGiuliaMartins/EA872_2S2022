main() {
  int varA=0,varB=0,varC;
  int teste;
  float ponto;
  int exemplo=2;
  varC=(varA+varB)*exemplo;
  teste=4;
  exemplo=(teste*varC)+varA+ponto;
  teste=0;
}
