main() {
  int i,j,k=2;
  i=0;
  j=i;
  i=k+3;
  i=j;
}
