#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <errno.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <string.h>

#define NOT_FOUND 404
#define FORBIDDEN 403

void read_and_print_file(char* file_string, struct stat fileStat);
