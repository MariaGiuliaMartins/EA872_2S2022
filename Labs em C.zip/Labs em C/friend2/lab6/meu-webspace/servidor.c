#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <time.h>
#include <fcntl.h>
#include <string.h>
#include <time.h>

int server(char d[],char f[],int resp){
    struct stat statinfo;
    int fd;
    char dir[200], file[50], index[250], welcome[250];
    strcpy(dir,d);
    strcpy(file,f);
    strcat(dir,file); //combinando os caminhos
    if (stat(dir, &statinfo) == -1){ //verificando a existencia do recurso
        return 404;
    }else{
        if(access(dir, R_OK)==0){ //verificando se a leitura eh permitida
            if((statinfo.st_mode & S_IFMT) == S_IFREG){ // caso seja um arquivo
                if ((fd = open(dir, O_RDONLY, 0600)) == -1){
                    return 500;
                }
                char buf[statinfo.st_size];
                read(fd, buf, sizeof(buf));
                write (STDOUT_FILENO, buf, sizeof(buf));
                write(resp,buf,sizeof(buf));
                return 0;
            }else if((statinfo.st_mode & S_IFMT) == S_IFDIR){ //caso seja um diretorio
                if(access(dir, X_OK) == 0){ //verificando permissao de varredura
                    strcpy(index,dir);
                    strcpy(welcome,dir);
                    strcat(index,"index.html");
                    strcat(welcome,"welcome.html");
                    if(stat(index, &statinfo) == 0 && access(index, R_OK)==0){
                        char buf[statinfo.st_size];
                        if ((fd = open(index, O_RDONLY, 0600)) == -1){
                            return 500;
                        }
                        read(fd, buf, sizeof(buf));
                        write (STDOUT_FILENO, buf, sizeof(buf));
                        write(resp,buf,sizeof(buf));
                        return 0;
                    }else if(stat(welcome, &statinfo) == 0 && access(welcome, R_OK)==0){
                        char buf[statinfo.st_size];
                        if ((fd = open(welcome, O_RDONLY, 0600)) == -1){
                            return 500;
                        }
                        read(fd, buf, sizeof(buf));
                        write (STDOUT_FILENO, buf, sizeof(buf));
                        write(resp,buf,sizeof(buf));
                        return 0;
                    }else{
                        if(stat(index, &statinfo) == 0 || stat(welcome, &statinfo) == 0){
                            return 403;
                        }
                        return 404;
                    }
                }else{
                    return 403;
                }
            }else{
                return 403;
            }
        }
        else{
            return 403;
        }
    }
}
int verify(char d[],char f[]){
    struct stat statinfo;
    int fd;
    char dir[200], file[50], index[250], welcome[250];
    strcpy(dir,d);
    strcpy(file,f);
    strcat(dir,file); //combinando os caminhos
    if (stat(dir, &statinfo) == -1){ //verificando a existencia do recurso
        return 404;
    }else{
        if(access(dir, R_OK)==0){ //verificando se a leitura eh permitida
            if((statinfo.st_mode & S_IFMT) == S_IFREG){ // caso seja um arquivo
                if ((fd = open(dir, O_RDONLY, 0600)) == -1){
                    return 500;
                }
                return 200;
            }else if((statinfo.st_mode & S_IFMT) == S_IFDIR){ //caso seja um diretorio
                if(access(dir, X_OK) == 0){ //verificando permissao de varredura
                    strcpy(index,dir);
                    strcpy(welcome,dir);
                    strcat(index,"index.html");
                    strcat(welcome,"welcome.html");
                    if(stat(index, &statinfo) == 0 && access(index, R_OK)==0){
                        if ((fd = open(index, O_RDONLY, 0600)) == -1){
                            return 500;
                        }
                        return 200;
                    }else if(stat(welcome, &statinfo) == 0 && access(welcome, R_OK)==0){
                        if ((fd = open(welcome, O_RDONLY, 0600)) == -1){
                            return 500;
                        }
                        return 200;
                    }else{
                        if(stat(index, &statinfo) == 0 || stat(welcome, &statinfo) == 0){
                            return 403;
                        }
                        return 404;
                    }
                }else{
                    return 403;
                }
            }else{
                return 403;
            }
        }
        else{
            return 403;
        }
    }
}
int req(char d[], char *dir, char *file,int resp, int reg){
    static char http[50];
    strcpy(http,d);
    if(!strcmp(http,"GET / HTTP/1.1")){
        int code = verify(dir,file);
        if(code==200){
            static char buff[5000];
            int letters = 0;
            letters += sprintf(buff+letters,"HTTP/1.1 %d\n",code);
            struct tm tm= *localtime(&(time_t){ time(NULL) });
            letters += sprintf(buff+letters,"Date: %s", asctime(&tm));
            letters += sprintf(buff+letters,"Server: Servidor HTTP ver. 0.1 de Caio Coldebella\n");
            letters += sprintf(buff+letters,"Connection: keep-alive\n");
            strcat(file,"index.html");
            char auxdir[200];
            strcpy(auxdir,dir);
            strcat(auxdir,file);
            int f = open(auxdir, O_RDONLY);
            struct stat statinfo;
            int i = fstat(f,&statinfo);
            letters += sprintf(buff+letters,"Last-Modified: %s",ctime(&statinfo.st_mtime));
            letters += sprintf(buff+letters,"Content-Length: %ld\n",statinfo.st_size);
            letters += sprintf(buff+letters,"Content-Type: text/html\n");
            write(resp,buff,letters);
            write(reg,"GET / HTTP/1.1\n",15);
            write(reg,buff,letters);
            write(reg,"\n",1);
            if(write(STDOUT_FILENO,buff,letters)==-1){
                return -1;
            }
            i = server(dir,file,resp);
            return 0;
        }
        else{
            printf("HTTP/1.1 %d\n",code);
        }
    }else if(!strcmp(http,"HEAD / HTTP/1.1")){
        int code = verify(dir,file);
        if(code==200){
            static char buff[5000];
            int letters = 0;
            letters += sprintf(buff+letters,"HTTP/1.1 %d\n",code);
            struct tm tm= *localtime(&(time_t){ time(NULL) });
            letters += sprintf(buff+letters,"Date: %s", asctime(&tm));
            letters += sprintf(buff+letters,"Server: Servidor HTTP ver. 0.1 de Caio Coldebella\n");
            letters += sprintf(buff+letters,"Connection: keep-alive\n");
            strcat(file,"index.html");
            char auxdir[200];
            strcpy(auxdir,dir);
            strcat(auxdir,file);
            int f = open(auxdir, O_RDONLY);
            struct stat statinfo;
            int i = fstat(f,&statinfo);
            letters += sprintf(buff+letters,"Last-Modified: %s",ctime(&statinfo.st_mtime));
            letters += sprintf(buff+letters,"Content-Length: %ld\n",statinfo.st_size);
            letters += sprintf(buff+letters,"Content-Type: text/html\n");
            write(resp,buff,letters);
            write(reg,"HEAD / HTTP/1.1\n",16);
            write(reg,buff,letters);
            write(reg,"\n",1);
            if(write(STDOUT_FILENO,buff,letters)==-1){
                return -1;
            }
            return 0;
        }
        else{
            printf("HTTP/1.1 %d\n",code);
        }
    }else if(!strcmp(http,"TRACE / HTTP/1.1")){
            static char buff[5000];
            int letters = 0;
            letters += sprintf(buff+letters,"HTTP/1.1 200\n");
            struct tm tm= *localtime(&(time_t){ time(NULL) });
            letters += sprintf(buff+letters,"Date: %s", asctime(&tm));
            letters += sprintf(buff+letters,"Server: Servidor HTTP ver. 0.1 de Caio Coldebella\n");
            letters += sprintf(buff+letters,"Content-Type: message/http\n");
            write(resp,buff,letters);
            write(reg,"TRACE / HTTP/1.1\n",17);
            write(reg,buff,letters);
            write(reg,"\n",1);
            if(write(STDOUT_FILENO,buff,letters)==-1){
                return -1;
            }
            return 0;
    }else{
            static char buff[5000];
            int letters = 0;
            letters += sprintf(buff+letters,"HTTP/1.1 200\n");
            struct tm tm= *localtime(&(time_t){ time(NULL) });
            letters += sprintf(buff+letters,"accept-encoding: gzip, deflate, br\n");
            letters += sprintf(buff+letters,"Accept: */*\n");
            letters += sprintf(buff+letters,"Connection: close\n");
            write(resp,buff,letters);
            write(reg,"OPTIONS / HTTP/1.1\n",19);
            write(reg,buff,letters);
            write(reg,"\n",1);
            if(write(STDOUT_FILENO,buff,letters)==-1){
                return -1;
            }
            return 0;
    }
}


#define dir argv[1]
#define reqN argv[2]
#define respN argv[3]
#define registro argv[4]

int main(int argc, char *argv[]){
    if(argc != 5){
        printf("Uso: ./servidor <Web Space> req_N.txt resp_N.txt registro.txt");
    }
    char file[200] = "";
    int request;
    int response;
    int registrofd;
    char requestbuff[5000];
    if ((request = open(reqN, O_RDONLY, 0600)) == -1){
        return -1;}
    if(read(request,requestbuff,sizeof(requestbuff)) == -1){
        return -1;}
    if ((response = creat(respN, 0600)) == -1){
        return -1;}
    if ((registrofd = open(registro, O_CREAT | O_WRONLY | O_APPEND, 0600)) == -1){
        return -1;}
    int i = req(requestbuff,dir,file,response,registrofd);
}
